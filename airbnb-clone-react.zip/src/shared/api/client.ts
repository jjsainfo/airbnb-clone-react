import axios from "axios";
import axiosRetry from "axios-retry";


const API_BASE_URL = 'https://91c48a924bb9.ngrok-free.app'

export const apiclient = axios.create({
    baseURL: API_BASE_URL,
    timeout: 10000, // 10 seconds
    headers: {
        "Content-Type": "application/json",
        "ngrok-skip-browser-warning": "true",
    },
   
});

axiosRetry(apiclient, {
    retries: 3,
    retryDelay: axiosRetry.exponentialDelay,
    retryCondition: (error) => {
        return error.response?.status === 503 || error.response?.status === 504;
    },
});
