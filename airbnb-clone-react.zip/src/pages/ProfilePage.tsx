function ProfilePage() {
    return (
        <div>
            <h1>soy Profile page</h1>
        </div>
    );
}    

export default ProfilePage