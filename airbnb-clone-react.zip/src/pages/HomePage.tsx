import { SearchBar, PropertyGrid } from "../features/properties";
import { useAuth } from "../shared/hooks/UseAuth";



function HomePage() {
    const{login} = useAuth();
    const handleLogin = () => {
        login();        
    };
  return (
    <>
      <button onClick={handleLogin} className="btn btn-primary">Login</button>
      <SearchBar />
      <PropertyGrid />
    </>
  );
}   

export default HomePage;